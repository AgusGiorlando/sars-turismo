<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'senderEmail' => 'noreply@example.com',
    'senderName' => 'Example.com mailer',
    'user.passwordResetTokenExpire' => 3600,
    'user.passwordMinLength' => 8,
    'contactPhoneNumber' => '5492614723149',
    'contactEmail' => 'reservas@sarsturismo.com.ar',
    'instagramUrl' => 'https://www.instagram.com/sarsturismo',
    'facebookUrl' => 'https://www.facebook.com/sars.turismo/',
    'tripadvisorUrl' => 'https://www.tripadvisor.es/Attraction_Review-g312781-d23187446-Reviews-SARS_TURISMO-Mendoza_Province_of_Mendoza_Cuyo.html?m=19905'
];

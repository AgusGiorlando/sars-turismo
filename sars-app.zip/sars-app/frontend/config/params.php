<?php
return [
    'adminEmail' => 'admin@example.com',
    'icon-framework' => 'fa',  // Font Awesome Icon framework

];

<?php
use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */

$this->title = 'SARS Dashboard';
?>
<div class="site-index">
    <?= Html::a('Ir al Sitio', ['site/frontend-index'], ['class' => 'btn btn-primary btn-lg', 'target' => '_blank']); ?>
</div>
